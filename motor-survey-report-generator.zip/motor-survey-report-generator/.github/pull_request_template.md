## Summary

Describe the change and why it is needed.

## Testing

- [ ] Tested in a current browser
- [ ] Checked browser console
- [ ] Checked print/PDF output if applicable
- [ ] Used fictional data only

## Safety and privacy

- [ ] No API keys, credentials or secrets added
- [ ] No real customer, policy, claim or vehicle documents included
- [ ] Data handling and documentation updated if applicable
