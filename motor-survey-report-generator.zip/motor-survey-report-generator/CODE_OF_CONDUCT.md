# Contributor Covenant Code of Conduct

## Our pledge

We pledge to make participation in this project a respectful experience for everyone, regardless of age, body size, disability, ethnicity, sex characteristics, gender identity and expression, level of experience, education, socio-economic status, nationality, personal appearance, race, religion, or sexual identity and orientation.

## Our standards

Examples of behaviour that contributes to a positive environment include:

- Being respectful and constructive.
- Accepting responsibility and correcting mistakes.
- Focusing on what is best for the project and its users.
- Showing empathy toward other contributors.

Unacceptable behaviour includes harassment, personal attacks, discriminatory language, publishing private information, and other conduct that would be inappropriate in a professional setting.

## Enforcement

Project maintainers are responsible for clarifying and enforcing this code. Report unacceptable behaviour privately to a maintainer through a verified contact channel on the repository profile. Maintainers may remove, edit or reject contributions that violate this code.

This policy is adapted from the Contributor Covenant, version 2.1: https://www.contributor-covenant.org/version/2/1/code_of_conduct.html
